# Çek Takip — Android proje dosyaları

Bu klasör, mevcut Çek Takip HTML uygulamasını Android WebView içinde çalıştıran bir Android Studio projesidir.

## Önemli durum
Bu teslim **APK dosyası değildir**. Bu çalışma ortamında Android SDK/Gradle derlemesi çalıştırılıp APK üretildiği doğrulanmadı. Proje dosyaları Android Studio ile derlenmek üzere hazırlandı.

## APK oluşturma (Android Studio)
1. Bilgisayarınıza Android Studio'yu kurun.
2. ZIP dosyasını bir klasöre çıkarın.
3. Android Studio → **Open** ile `CekTakipAndroid` klasörünü açın (içinde `settings.gradle` dosyası olan klasör).
4. Gradle eşitlemesi tamamlanana kadar bekleyin. İstenirse Android SDK Platform 35 ve uyumlu Android Build Tools bileşenlerini yükleyin.
5. Menüden **Build → Build Bundle(s) / APK(s) → Build APK(s)** seçin.
6. Derleme başarılı olursa Android Studio bildirimindeki **locate** bağlantısına basın. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
7. APK'yı telefona aktarın ve açın. Android isterse yalnızca bu yükleme için “bilinmeyen uygulama yükleme izni” verin. Güvenmediğiniz APK'ları yüklemeyin.

## Uygulama özellikleri ve veri
- Çek ekleme, düzenleme, silme ve CSV dışa aktarma HTML uygulamasından gelir.
- Veriler WebView yerel tarayıcı depolamasında bu cihazda tutulur; bu sürümde bulut senkronizasyonu veya otomatik yedekleme yoktur.
- Uygulamayı kaldırmak veya uygulama verilerini temizlemek yerel kayıtları silebilir. CSV dışa aktarma ile düzenli yedek alın.
- Gerçek finansal kayıtlarla kullanmadan önce test verileriyle doğrulayın.

## Teknik
- Application ID: `com.pusula.cektakip`
- Minimum Android: API 23 (Android 6.0)
- Target/Compile SDK: 35
- Java tabanlı, harici uygulama kütüphanesi gerektirmeyen WebView sarmalayıcı.
